import axios from 'axios';

const movieDB = axios.create({
    baseURL: 'https://api.themoviedb.org/3/movie',
    params: {
        api_key: 'd1b0a6ab313d282db272e229e13812bc',
        language: 'es-ES'
    }
})

export default movieDB;