import React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';
import { Movie } from '../interfaces/movieInterface';



interface Props {
    movie: Movie;    
}

export const MovieCard = ({ movie }: Props ) => {
    console.log( movie.poster_path );
    return (
        <View style={{
            width: '100%',
            height: 96,
            backgroundColor: 'red'
        }}>
            <Image
                source={require('../assets/back.jpg')}
                style={ styles.image }
            />
            <Text style={ styles.text }>{ movie.title }</Text>
        </View>
    )
}


const styles = StyleSheet.create({

    text: {
        color: '#333',
        fontSize: 16,
    },

    image: {
        width: 100,
        height: 100,
    },

});
