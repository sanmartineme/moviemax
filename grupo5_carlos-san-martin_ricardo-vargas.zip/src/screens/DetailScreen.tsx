import React from 'react';
import { Text, View, Image, StyleSheet } from 'react-native';

export const DetailScreen = () => {
    return (
        <View>
            <Image source={require('../assets/back.jpg')} style={styles.ImageBackground} />
            <Text style={styles.Title}>Nombre de la Película</Text>
            <Text style={styles.Detail}>[Año] - [Categoría] - [Duración]</Text>
            <Text style={styles.Subtitle}>Resumen</Text>
            <Text style={styles.Paragraph}>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
          aliquip ex ea commodo consequat. Duis aute irure dolor in
          reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
          pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
          culpa qui officia deserunt mollit anim id est laborum.</Text>
        </View>
    )
}

const styles = StyleSheet.create({
    Title: {
        fontSize: 24,
        color: '#fff',
        position: 'absolute',
        top: 200,
        left: '20%',
        fontWeight: 'bold',
        textAlign: 'center',
        alignContent: 'center',
    },

    Detail: {
        fontSize: 16,
        color: '#FFF',
        textAlign: 'center',
        position: 'absolute',
        top: 240,
        left: '22%',
        fontWeight: '100',

    },

    Paragraph: {
        fontSize: 16,
        color: '#333',
        textAlign: 'left',
        marginTop: 16,
        marginLeft: 16,
        marginRight: 16,
        fontWeight: '100',
    },

    Subtitle: {
        fontSize: 16,
        color: '#333',
        textAlign: 'left',
        marginTop: 60,
        marginLeft: 16,
        marginRight: 16,
        fontWeight: 'bold',
    },

    

    ImageBackground: {
        width: '100%',
        height: 285,
       

    },
    
})