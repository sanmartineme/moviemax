import React from 'react';
import { useNavigation } from '@react-navigation/core';
import { Text, View, StyleSheet, ActivityIndicator, TouchableOpacity, Image, ScrollView} from 'react-native';
import { useMovies } from '../hooks/useMovies';
import { MovieCard } from '../components/movieCard';





export const ListScreen = () => {

    const { peliculasEnCine, isLoading, } = useMovies();

    if ( isLoading ) {
        return (
            <View style={{ flex:1, justifyContent: 'center', alignContent: 'center' }}>
                <ActivityIndicator color="#333" size={64} />
            </View>
        )
    }

    const navigation = useNavigation();

    return (

        <ScrollView>
            
            <Text style={styles.title}>Te presentamos las mejores películas</Text>
            <Text style={styles.paragraph}>Selecciona la película de tu preferencia</Text>
            <TouchableOpacity style={styles.btn} onPress={ () => navigation.navigate('DetailScreen')}>
                <Text style={styles.movietitle}>Título de la Película</Text>
                <Text style={styles.movieclasifi}>[Clasificación 0/0]</Text>
                <Text style={styles.etiquetas}>[Categoría, Año]</Text>
                <Image source={require('../assets/back.jpg')} style={styles.ImageBackground} />
            </TouchableOpacity>

            <TouchableOpacity style={styles.btn} onPress={ () => navigation.navigate('DetailScreen')}>
                <Text style={styles.movietitle}>Título de la Película</Text>
                <Text style={styles.movieclasifi}>[Clasificación 0/0]</Text>
                <Text style={styles.etiquetas}>[Categoría, Año]</Text>
                <Image source={require('../assets/back.jpg')} style={styles.ImageBackground} />
            </TouchableOpacity>

            <TouchableOpacity style={styles.btn} onPress={ () => navigation.navigate('DetailScreen')}>
                <Text style={styles.movietitle}>Título de la Película</Text>
                <Text style={styles.movieclasifi}>[Clasificación 0/0]</Text>
                <Text style={styles.etiquetas}>[Categoría, Año]</Text>
                <Image source={require('../assets/back.jpg')} style={styles.ImageBackground} />
            </TouchableOpacity>

            <TouchableOpacity style={styles.btn} onPress={ () => navigation.navigate('DetailScreen')}>
                <Text style={styles.movietitle}>Título de la Película</Text>
                <Text style={styles.movieclasifi}>[Clasificación 0/0]</Text>
                <Text style={styles.etiquetas}>[Categoría, Año]</Text>
                <Image source={require('../assets/back.jpg')} style={styles.ImageBackground} />
            </TouchableOpacity>

            <TouchableOpacity style={styles.btn} onPress={ () => navigation.navigate('DetailScreen')}>
                <Text style={styles.movietitle}>Título de la Película</Text>
                <Text style={styles.movieclasifi}>[Clasificación 0/0]</Text>
                <Text style={styles.etiquetas}>[Categoría, Año]</Text>
                <Image source={require('../assets/back.jpg')} style={styles.ImageBackground} />
            </TouchableOpacity>

            <TouchableOpacity style={styles.btn} onPress={ () => navigation.navigate('DetailScreen')}>
                <Text style={styles.movietitle}>Título de la Película</Text>
                <Text style={styles.movieclasifi}>[Clasificación 0/0]</Text>
                <Text style={styles.etiquetas}>[Categoría, Año]</Text>
                <Image source={require('../assets/back.jpg')} style={styles.ImageBackground} />
            </TouchableOpacity>
            
        </ScrollView>
    )


    return (
        <View>
            <MovieCard 
                movie={ peliculasEnCine[0] }
            />
        </View>
    )




    
}

const styles = StyleSheet.create({
    title: {
        fontSize: 24,
        color: '#333',
        marginTop: 24,
        marginLeft: 16,
        fontWeight: 'bold',
    },

    paragraph: {
        fontSize: 16,
        color: '#333',
        marginTop: 24,
        marginLeft: 16,
        fontWeight: '200',
        textAlign: 'left',
    },

    btn: {
        width: '92%',
        marginLeft: 16,
        marginRight: 16,
        height: 96,
        marginTop: 8,
        marginBottom: 24,
        alignContent: 'flex-start',
    },

    ImageBackground: {
        width: 192,
        height: 96,
        borderRadius: 8,
        alignItems: 'flex-start',
        marginTop: -94,
        alignSelf: 'flex-start',

    },

    movietitle : {
        fontSize: 16,
        color: '#333',
        textAlign: 'right',
    
     
    },

    movieclasifi : {
        fontSize: 16,
        color: '#333',
        textAlign: 'right',
        fontWeight: 'bold',
     
    },

    etiquetas : {
        fontSize: 14,
        color: '#999',
        textAlign: 'right',
        fontWeight: '100',
        marginTop: 36,
     
    },
    
    
})




