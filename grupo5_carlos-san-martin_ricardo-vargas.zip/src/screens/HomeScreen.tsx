import { useNavigation } from '@react-navigation/core';
import 'react-native-gesture-handler';
import React from 'react';
import { StyleSheet, Text, Image, View, Button, TouchableOpacity } from 'react-native';
import { ListScreen } from './ListScreen';


export const HomeScreen = () => {

    
    
    
    const navigation = useNavigation();

    return (

        <View>
            <Image source={require('../assets/back.jpg')} style={styles.ImageBackground} />
            <Text style={styles.Title}>Bienvenido a Moviemax App</Text>
            <Text style={styles.Paragraph}>Las mejores películas en un
solo lugar.</Text>
            <TouchableOpacity style={styles.btn} onPress={ () => navigation.navigate('ListScreen')}>
                <Text>Continuar</Text> 
            </TouchableOpacity>
            
        </View>
    )
}


const styles = StyleSheet.create({
    Title: {
        fontSize: 36,
        color: '#fff',
        position: 'absolute',
        top: 154,
        width: 280,
        left: 16,
        fontWeight: 'bold',
    },

    TextButton: {
        fontSize: 16,
        color: '#333',
        textAlign: 'center',

    },

    Paragraph: {
        fontSize: 24,
        color: '#FFF',
        textAlign: 'left',
        position: 'absolute',
        top: 254,
        width: 320,
        left: 16,
        

    },

    btn: {
        alignContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
        paddingTop: 16,
        paddingBottom: 16,
        borderRadius: 50,
        opacity: 0.9,
        fontSize: 16,
        color: '#333',
        textAlign: 'center',
        width: 155,
        position: 'absolute',
        top: 454,
        left:'32%',
        fontWeight: '200',
       

    },

    ImageBackground: {
        width: '100%',
        height: '100%',
       

    },
    
})